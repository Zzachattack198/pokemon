﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokemonGame
{
    public partial class Battle : Form
    {

        public Battle(Image BackgroundImage1, Image BackgroundImage2, Image BackgroundImage3, Image BackgroundImage4, Image BackgroundImage5, Image BackgroundImage6, Image BackgroundImage7, Image BackgroundImage8, Image BackgroundImage9, Image BackgroundImage10, Image BackgroundImage11, Image BackgroundImage12)
        {
            InitializeComponent();
            team1Poke.BackgroundImage = BackgroundImage1;
            team2Poke.BackgroundImage = BackgroundImage7;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}

