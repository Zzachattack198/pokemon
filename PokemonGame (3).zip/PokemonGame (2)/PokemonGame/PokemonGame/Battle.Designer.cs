﻿namespace PokemonGame
{
    partial class Battle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            team1Poke = new PictureBox();
            team2Poke = new PictureBox();
            progressBar1 = new ProgressBar();
            progressBar2 = new ProgressBar();
            TextBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)team1Poke).BeginInit();
            ((System.ComponentModel.ISupportInitialize)team2Poke).BeginInit();
            SuspendLayout();
            // 
            // team1Poke
            // 
            team1Poke.Location = new Point(245, 684);
            team1Poke.Margin = new Padding(8, 7, 8, 7);
            team1Poke.Name = "team1Poke";
            team1Poke.Size = new Size(575, 396);
            team1Poke.TabIndex = 0;
            team1Poke.TabStop = false;
            // 
            // team2Poke
            // 
            team2Poke.Location = new Point(1490, 401);
            team2Poke.Margin = new Padding(8, 7, 8, 7);
            team2Poke.Name = "team2Poke";
            team2Poke.Size = new Size(575, 396);
            team2Poke.TabIndex = 1;
            team2Poke.TabStop = false;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(1630, 1082);
            progressBar1.Margin = new Padding(8, 7, 8, 7);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(570, 89);
            progressBar1.TabIndex = 2;
            progressBar1.Click += progressBar1_Click;
            // 
            // progressBar2
            // 
            progressBar2.Location = new Point(232, 106);
            progressBar2.Margin = new Padding(8, 7, 8, 7);
            progressBar2.Name = "progressBar2";
            progressBar2.Size = new Size(570, 89);
            progressBar2.TabIndex = 3;
            // 
            // TextBox1
            // 
            TextBox1.Location = new Point(508, 490);
            TextBox1.Margin = new Padding(8, 7, 8, 7);
            TextBox1.Name = "TextBox1";
            TextBox1.Size = new Size(306, 55);
            TextBox1.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(-5, 1082);
            button1.Margin = new Padding(8, 7, 8, 7);
            button1.Name = "button1";
            button1.Size = new Size(415, 216);
            button1.TabIndex = 5;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(401, 1082);
            button2.Margin = new Padding(8, 7, 8, 7);
            button2.Name = "button2";
            button2.Size = new Size(419, 216);
            button2.TabIndex = 6;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(814, 1082);
            button3.Margin = new Padding(8, 7, 8, 7);
            button3.Name = "button3";
            button3.Size = new Size(419, 216);
            button3.TabIndex = 7;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(1230, 1082);
            button4.Margin = new Padding(8, 7, 8, 7);
            button4.Name = "button4";
            button4.Size = new Size(419, 216);
            button4.TabIndex = 8;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // Battle
            // 
            AutoScaleDimensions = new SizeF(20F, 48F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(2338, 1298);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(TextBox1);
            Controls.Add(progressBar2);
            Controls.Add(progressBar1);
            Controls.Add(team2Poke);
            Controls.Add(team1Poke);
            Margin = new Padding(8, 7, 8, 7);
            Name = "Battle";
            Text = "Battle";
            ((System.ComponentModel.ISupportInitialize)team1Poke).EndInit();
            ((System.ComponentModel.ISupportInitialize)team2Poke).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox team1Poke;
        private PictureBox team2Poke;
        private ProgressBar progressBar1;
        private ProgressBar progressBar2;
        private TextBox TextBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}