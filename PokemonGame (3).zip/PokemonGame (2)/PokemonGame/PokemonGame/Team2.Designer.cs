﻿namespace PokemonGame
{
    partial class Team2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Team2));
            tm2pokemon1 = new PictureBox();
            tm2pokemon2 = new PictureBox();
            tm2pokemon3 = new PictureBox();
            tm2pokemon4 = new PictureBox();
            tm2pokemon5 = new PictureBox();
            tm2pokemon6 = new PictureBox();
            butToxicroak = new Button();
            butSylveon = new Button();
            butGroudon = new Button();
            butVikavolt = new Button();
            butBarbaracle = new Button();
            butToxapex = new Button();
            butTalonflame = new Button();
            butZapdos = new Button();
            butSteelix = new Button();
            butAerodactyl = new Button();
            butGengar = new Button();
            butGardevoir = new Button();
            butKrookodile = new Button();
            butFroslass = new Button();
            butIncineroar = new Button();
            butMetagross = new Button();
            butLucario = new Button();
            butTyranitar = new Button();
            butShedinja = new Button();
            butPikachu = new Button();
            butDragonite = new Button();
            butKyogre = new Button();
            butDragapult = new Button();
            butSceptile = new Button();
            butBlaziken = new Button();
            butArticuno = new Button();
            butMewtwo = new Button();
            butVenusaur = new Button();
            butBlastoise = new Button();
            butCharizard = new Button();
            butChoosePoke = new Button();
            buttonQuit = new Button();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon6).BeginInit();
            SuspendLayout();
            // 
            // tm2pokemon1
            // 
            tm2pokemon1.BackgroundImage = Properties.Resources.Pokeball;
            tm2pokemon1.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon1.Location = new Point(30, 29);
            tm2pokemon1.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon1.Name = "tm2pokemon1";
            tm2pokemon1.Size = new Size(345, 221);
            tm2pokemon1.TabIndex = 44;
            tm2pokemon1.TabStop = false;
            tm2pokemon1.Click += pokemon1_Click;
            // 
            // tm2pokemon2
            // 
            tm2pokemon2.BackgroundImage = Properties.Resources.Pokeball;
            tm2pokemon2.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon2.Location = new Point(30, 264);
            tm2pokemon2.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon2.Name = "tm2pokemon2";
            tm2pokemon2.Size = new Size(345, 221);
            tm2pokemon2.TabIndex = 45;
            tm2pokemon2.TabStop = false;
            // 
            // tm2pokemon3
            // 
            tm2pokemon3.BackgroundImage = Properties.Resources.Pokeball;
            tm2pokemon3.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon3.Location = new Point(30, 499);
            tm2pokemon3.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon3.Name = "tm2pokemon3";
            tm2pokemon3.Size = new Size(345, 221);
            tm2pokemon3.TabIndex = 46;
            tm2pokemon3.TabStop = false;
            tm2pokemon3.Click += pokemon3_Click;
            // 
            // tm2pokemon4
            // 
            tm2pokemon4.BackgroundImage = Properties.Resources.Pokeball;
            tm2pokemon4.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon4.Location = new Point(30, 734);
            tm2pokemon4.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon4.Name = "tm2pokemon4";
            tm2pokemon4.Size = new Size(345, 221);
            tm2pokemon4.TabIndex = 47;
            tm2pokemon4.TabStop = false;
            tm2pokemon4.Click += pokemon4_Click;
            // 
            // tm2pokemon5
            // 
            tm2pokemon5.BackgroundImage = Properties.Resources.Pokeball;
            tm2pokemon5.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon5.Location = new Point(30, 970);
            tm2pokemon5.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon5.Name = "tm2pokemon5";
            tm2pokemon5.Size = new Size(345, 221);
            tm2pokemon5.TabIndex = 48;
            tm2pokemon5.TabStop = false;
            tm2pokemon5.Click += pokemon5_Click;
            // 
            // tm2pokemon6
            // 
            tm2pokemon6.BackgroundImage = (Image)resources.GetObject("tm2pokemon6.BackgroundImage");
            tm2pokemon6.BackgroundImageLayout = ImageLayout.Zoom;
            tm2pokemon6.Location = new Point(30, 1205);
            tm2pokemon6.Margin = new Padding(8, 7, 8, 7);
            tm2pokemon6.Name = "tm2pokemon6";
            tm2pokemon6.Size = new Size(345, 221);
            tm2pokemon6.TabIndex = 49;
            tm2pokemon6.TabStop = false;
            tm2pokemon6.Click += pokemon6_Click;
            // 
            // butToxicroak
            // 
            butToxicroak.Anchor = AnchorStyles.Right;
            butToxicroak.BackgroundImage = (Image)resources.GetObject("butToxicroak.BackgroundImage");
            butToxicroak.BackgroundImageLayout = ImageLayout.Zoom;
            butToxicroak.Location = new Point(1705, 542);
            butToxicroak.Margin = new Padding(8, 7, 8, 7);
            butToxicroak.Name = "butToxicroak";
            butToxicroak.Size = new Size(438, 288);
            butToxicroak.TabIndex = 79;
            butToxicroak.UseVisualStyleBackColor = true;
            butToxicroak.Click += butToxapex_Click;
            // 
            // butSylveon
            // 
            butSylveon.Anchor = AnchorStyles.Right;
            butSylveon.BackgroundImage = (Image)resources.GetObject("butSylveon.BackgroundImage");
            butSylveon.BackgroundImageLayout = ImageLayout.Zoom;
            butSylveon.Location = new Point(2135, 1094);
            butSylveon.Margin = new Padding(8, 7, 8, 7);
            butSylveon.Name = "butSylveon";
            butSylveon.Size = new Size(438, 288);
            butSylveon.TabIndex = 78;
            butSylveon.UseVisualStyleBackColor = true;
            butSylveon.Click += butSylveon_Click;
            // 
            // butGroudon
            // 
            butGroudon.Anchor = AnchorStyles.Right;
            butGroudon.BackgroundImage = (Image)resources.GetObject("butGroudon.BackgroundImage");
            butGroudon.BackgroundImageLayout = ImageLayout.Zoom;
            butGroudon.Location = new Point(2135, 1666);
            butGroudon.Margin = new Padding(8, 7, 8, 7);
            butGroudon.Name = "butGroudon";
            butGroudon.Size = new Size(438, 288);
            butGroudon.TabIndex = 77;
            butGroudon.UseVisualStyleBackColor = true;
            butGroudon.Click += butGroudon_Click;
            // 
            // butVikavolt
            // 
            butVikavolt.Anchor = AnchorStyles.Right;
            butVikavolt.BackgroundImage = (Image)resources.GetObject("butVikavolt.BackgroundImage");
            butVikavolt.BackgroundImageLayout = ImageLayout.Zoom;
            butVikavolt.Location = new Point(855, 1094);
            butVikavolt.Margin = new Padding(8, 7, 8, 7);
            butVikavolt.Name = "butVikavolt";
            butVikavolt.Size = new Size(438, 288);
            butVikavolt.TabIndex = 76;
            butVikavolt.UseVisualStyleBackColor = true;
            butVikavolt.Click += butVikavolt_Click;
            // 
            // butBarbaracle
            // 
            butBarbaracle.Anchor = AnchorStyles.Right;
            butBarbaracle.BackgroundImage = (Image)resources.GetObject("butBarbaracle.BackgroundImage");
            butBarbaracle.BackgroundImageLayout = ImageLayout.Zoom;
            butBarbaracle.Location = new Point(855, 264);
            butBarbaracle.Margin = new Padding(8, 7, 8, 7);
            butBarbaracle.Name = "butBarbaracle";
            butBarbaracle.Size = new Size(438, 288);
            butBarbaracle.TabIndex = 75;
            butBarbaracle.UseVisualStyleBackColor = true;
            butBarbaracle.Click += butBarbaracle_Click;
            // 
            // butToxapex
            // 
            butToxapex.Anchor = AnchorStyles.Right;
            butToxapex.BackgroundImage = (Image)resources.GetObject("butToxapex.BackgroundImage");
            butToxapex.BackgroundImageLayout = ImageLayout.Zoom;
            butToxapex.Location = new Point(1292, 542);
            butToxapex.Margin = new Padding(8, 7, 8, 7);
            butToxapex.Name = "butToxapex";
            butToxapex.Size = new Size(438, 288);
            butToxapex.TabIndex = 74;
            butToxapex.UseVisualStyleBackColor = true;
            butToxapex.Click += butToxapex_Click;
            // 
            // butTalonflame
            // 
            butTalonflame.Anchor = AnchorStyles.Right;
            butTalonflame.BackgroundImage = (Image)resources.GetObject("butTalonflame.BackgroundImage");
            butTalonflame.BackgroundImageLayout = ImageLayout.Zoom;
            butTalonflame.Location = new Point(2135, 1375);
            butTalonflame.Margin = new Padding(8, 7, 8, 7);
            butTalonflame.Name = "butTalonflame";
            butTalonflame.Size = new Size(438, 288);
            butTalonflame.TabIndex = 73;
            butTalonflame.UseVisualStyleBackColor = true;
            butTalonflame.Click += butTalonflame_Click;
            // 
            // butZapdos
            // 
            butZapdos.Anchor = AnchorStyles.Right;
            butZapdos.BackgroundImage = (Image)resources.GetObject("butZapdos.BackgroundImage");
            butZapdos.BackgroundImageLayout = ImageLayout.Zoom;
            butZapdos.Location = new Point(1292, 1666);
            butZapdos.Margin = new Padding(8, 7, 8, 7);
            butZapdos.Name = "butZapdos";
            butZapdos.Size = new Size(438, 288);
            butZapdos.TabIndex = 72;
            butZapdos.UseVisualStyleBackColor = true;
            butZapdos.Click += butZapdos_Click;
            // 
            // butSteelix
            // 
            butSteelix.Anchor = AnchorStyles.Right;
            butSteelix.BackgroundImage = (Image)resources.GetObject("butSteelix.BackgroundImage");
            butSteelix.BackgroundImageLayout = ImageLayout.Zoom;
            butSteelix.Location = new Point(2135, 823);
            butSteelix.Margin = new Padding(8, 7, 8, 7);
            butSteelix.Name = "butSteelix";
            butSteelix.Size = new Size(438, 288);
            butSteelix.TabIndex = 71;
            butSteelix.UseVisualStyleBackColor = true;
            butSteelix.Click += butSteelix_Click;
            // 
            // butAerodactyl
            // 
            butAerodactyl.Anchor = AnchorStyles.Right;
            butAerodactyl.BackgroundImage = (Image)resources.GetObject("butAerodactyl.BackgroundImage");
            butAerodactyl.BackgroundImageLayout = ImageLayout.Zoom;
            butAerodactyl.Location = new Point(425, 1375);
            butAerodactyl.Margin = new Padding(8, 7, 8, 7);
            butAerodactyl.Name = "butAerodactyl";
            butAerodactyl.Size = new Size(438, 288);
            butAerodactyl.TabIndex = 70;
            butAerodactyl.UseVisualStyleBackColor = true;
            butAerodactyl.Click += butAerodactyl_Click;
            // 
            // butGengar
            // 
            butGengar.Anchor = AnchorStyles.Right;
            butGengar.BackgroundImage = (Image)resources.GetObject("butGengar.BackgroundImage");
            butGengar.BackgroundImageLayout = ImageLayout.Zoom;
            butGengar.Location = new Point(425, 823);
            butGengar.Margin = new Padding(8, 7, 8, 7);
            butGengar.Name = "butGengar";
            butGengar.Size = new Size(438, 288);
            butGengar.TabIndex = 69;
            butGengar.UseVisualStyleBackColor = true;
            butGengar.Click += butGengar_Click;
            // 
            // butGardevoir
            // 
            butGardevoir.Anchor = AnchorStyles.Right;
            butGardevoir.BackgroundImage = (Image)resources.GetObject("butGardevoir.BackgroundImage");
            butGardevoir.BackgroundImageLayout = ImageLayout.Zoom;
            butGardevoir.Location = new Point(1705, 1094);
            butGardevoir.Margin = new Padding(8, 7, 8, 7);
            butGardevoir.Name = "butGardevoir";
            butGardevoir.Size = new Size(438, 288);
            butGardevoir.TabIndex = 68;
            butGardevoir.UseVisualStyleBackColor = true;
            butGardevoir.Click += butGardevoir_Click;
            // 
            // butKrookodile
            // 
            butKrookodile.Anchor = AnchorStyles.Right;
            butKrookodile.BackgroundImage = (Image)resources.GetObject("butKrookodile.BackgroundImage");
            butKrookodile.BackgroundImageLayout = ImageLayout.Zoom;
            butKrookodile.Location = new Point(1292, 1375);
            butKrookodile.Margin = new Padding(8, 7, 8, 7);
            butKrookodile.Name = "butKrookodile";
            butKrookodile.Size = new Size(438, 288);
            butKrookodile.TabIndex = 67;
            butKrookodile.UseVisualStyleBackColor = true;
            butKrookodile.Click += butKrookodile_Click;
            // 
            // butFroslass
            // 
            butFroslass.Anchor = AnchorStyles.Right;
            butFroslass.BackgroundImage = (Image)resources.GetObject("butFroslass.BackgroundImage");
            butFroslass.BackgroundImageLayout = ImageLayout.Zoom;
            butFroslass.Location = new Point(855, 823);
            butFroslass.Margin = new Padding(8, 7, 8, 7);
            butFroslass.Name = "butFroslass";
            butFroslass.Size = new Size(438, 288);
            butFroslass.TabIndex = 66;
            butFroslass.UseVisualStyleBackColor = true;
            butFroslass.Click += butFroslass_Click;
            // 
            // butIncineroar
            // 
            butIncineroar.Anchor = AnchorStyles.Right;
            butIncineroar.BackgroundImage = (Image)resources.GetObject("butIncineroar.BackgroundImage");
            butIncineroar.BackgroundImageLayout = ImageLayout.Zoom;
            butIncineroar.Location = new Point(1292, 264);
            butIncineroar.Margin = new Padding(8, 7, 8, 7);
            butIncineroar.Name = "butIncineroar";
            butIncineroar.Size = new Size(438, 288);
            butIncineroar.TabIndex = 65;
            butIncineroar.UseVisualStyleBackColor = true;
            butIncineroar.Click += butIncineroar_Click;
            // 
            // butMetagross
            // 
            butMetagross.Anchor = AnchorStyles.Right;
            butMetagross.BackgroundImage = (Image)resources.GetObject("butMetagross.BackgroundImage");
            butMetagross.BackgroundImageLayout = ImageLayout.Zoom;
            butMetagross.Location = new Point(1705, 823);
            butMetagross.Margin = new Padding(8, 7, 8, 7);
            butMetagross.Name = "butMetagross";
            butMetagross.Size = new Size(438, 288);
            butMetagross.TabIndex = 64;
            butMetagross.UseVisualStyleBackColor = true;
            butMetagross.Click += butMetagross_Click;
            // 
            // butLucario
            // 
            butLucario.Anchor = AnchorStyles.Right;
            butLucario.BackgroundImage = (Image)resources.GetObject("butLucario.BackgroundImage");
            butLucario.BackgroundImageLayout = ImageLayout.Zoom;
            butLucario.Location = new Point(2135, 542);
            butLucario.Margin = new Padding(8, 7, 8, 7);
            butLucario.Name = "butLucario";
            butLucario.Size = new Size(438, 288);
            butLucario.TabIndex = 63;
            butLucario.UseVisualStyleBackColor = true;
            butLucario.Click += butLucario_Click;
            // 
            // butTyranitar
            // 
            butTyranitar.Anchor = AnchorStyles.Right;
            butTyranitar.BackgroundImage = (Image)resources.GetObject("butTyranitar.BackgroundImage");
            butTyranitar.BackgroundImageLayout = ImageLayout.Zoom;
            butTyranitar.Location = new Point(855, 1375);
            butTyranitar.Margin = new Padding(8, 7, 8, 7);
            butTyranitar.Name = "butTyranitar";
            butTyranitar.Size = new Size(438, 288);
            butTyranitar.TabIndex = 62;
            butTyranitar.UseVisualStyleBackColor = true;
            butTyranitar.Click += butTyranitar_Click;
            // 
            // butShedinja
            // 
            butShedinja.Anchor = AnchorStyles.Right;
            butShedinja.BackgroundImage = (Image)resources.GetObject("butShedinja.BackgroundImage");
            butShedinja.BackgroundImageLayout = ImageLayout.Zoom;
            butShedinja.Location = new Point(1292, 1094);
            butShedinja.Margin = new Padding(8, 7, 8, 7);
            butShedinja.Name = "butShedinja";
            butShedinja.Size = new Size(438, 288);
            butShedinja.TabIndex = 61;
            butShedinja.UseVisualStyleBackColor = true;
            butShedinja.Click += butShedinja_Click;
            // 
            // butPikachu
            // 
            butPikachu.Anchor = AnchorStyles.Right;
            butPikachu.BackgroundImage = (Image)resources.GetObject("butPikachu.BackgroundImage");
            butPikachu.BackgroundImageLayout = ImageLayout.Zoom;
            butPikachu.Location = new Point(425, 1094);
            butPikachu.Margin = new Padding(8, 7, 8, 7);
            butPikachu.Name = "butPikachu";
            butPikachu.Size = new Size(438, 288);
            butPikachu.TabIndex = 60;
            butPikachu.UseVisualStyleBackColor = true;
            butPikachu.Click += butPikachu_Click;
            // 
            // butDragonite
            // 
            butDragonite.Anchor = AnchorStyles.Right;
            butDragonite.BackgroundImage = (Image)resources.GetObject("butDragonite.BackgroundImage");
            butDragonite.BackgroundImageLayout = ImageLayout.Zoom;
            butDragonite.Location = new Point(1705, 1375);
            butDragonite.Margin = new Padding(8, 7, 8, 7);
            butDragonite.Name = "butDragonite";
            butDragonite.Size = new Size(438, 288);
            butDragonite.TabIndex = 59;
            butDragonite.UseVisualStyleBackColor = true;
            butDragonite.Click += butDragonite_Click;
            // 
            // butKyogre
            // 
            butKyogre.Anchor = AnchorStyles.Right;
            butKyogre.BackgroundImage = (Image)resources.GetObject("butKyogre.BackgroundImage");
            butKyogre.BackgroundImageLayout = ImageLayout.Zoom;
            butKyogre.Location = new Point(425, 1666);
            butKyogre.Margin = new Padding(8, 7, 8, 7);
            butKyogre.Name = "butKyogre";
            butKyogre.Size = new Size(438, 288);
            butKyogre.TabIndex = 58;
            butKyogre.UseVisualStyleBackColor = true;
            butKyogre.Click += butKyogre_Click;
            // 
            // butDragapult
            // 
            butDragapult.Anchor = AnchorStyles.Right;
            butDragapult.BackgroundImage = (Image)resources.GetObject("butDragapult.BackgroundImage");
            butDragapult.BackgroundImageLayout = ImageLayout.Zoom;
            butDragapult.Location = new Point(1292, 823);
            butDragapult.Margin = new Padding(8, 7, 8, 7);
            butDragapult.Name = "butDragapult";
            butDragapult.Size = new Size(438, 288);
            butDragapult.TabIndex = 57;
            butDragapult.UseVisualStyleBackColor = true;
            butDragapult.Click += butDragapult_Click;
            // 
            // butSceptile
            // 
            butSceptile.Anchor = AnchorStyles.Right;
            butSceptile.BackgroundImage = (Image)resources.GetObject("butSceptile.BackgroundImage");
            butSceptile.BackgroundImageLayout = ImageLayout.Zoom;
            butSceptile.Location = new Point(855, 542);
            butSceptile.Margin = new Padding(8, 7, 8, 7);
            butSceptile.Name = "butSceptile";
            butSceptile.Size = new Size(438, 288);
            butSceptile.TabIndex = 56;
            butSceptile.UseVisualStyleBackColor = true;
            butSceptile.Click += butSceptile_Click;
            // 
            // butBlaziken
            // 
            butBlaziken.Anchor = AnchorStyles.Right;
            butBlaziken.BackgroundImage = (Image)resources.GetObject("butBlaziken.BackgroundImage");
            butBlaziken.BackgroundImageLayout = ImageLayout.Zoom;
            butBlaziken.Location = new Point(2135, 264);
            butBlaziken.Margin = new Padding(8, 7, 8, 7);
            butBlaziken.Name = "butBlaziken";
            butBlaziken.Size = new Size(438, 288);
            butBlaziken.TabIndex = 55;
            butBlaziken.UseVisualStyleBackColor = true;
            butBlaziken.Click += butBlaziken_Click;
            // 
            // butArticuno
            // 
            butArticuno.Anchor = AnchorStyles.Right;
            butArticuno.BackgroundImage = (Image)resources.GetObject("butArticuno.BackgroundImage");
            butArticuno.BackgroundImageLayout = ImageLayout.Zoom;
            butArticuno.Location = new Point(855, 1666);
            butArticuno.Margin = new Padding(8, 7, 8, 7);
            butArticuno.Name = "butArticuno";
            butArticuno.Size = new Size(438, 288);
            butArticuno.TabIndex = 54;
            butArticuno.UseVisualStyleBackColor = true;
            butArticuno.Click += butArticuno_Click;
            // 
            // butMewtwo
            // 
            butMewtwo.Anchor = AnchorStyles.Right;
            butMewtwo.BackgroundImage = (Image)resources.GetObject("butMewtwo.BackgroundImage");
            butMewtwo.BackgroundImageLayout = ImageLayout.Zoom;
            butMewtwo.Location = new Point(1705, 1666);
            butMewtwo.Margin = new Padding(8, 7, 8, 7);
            butMewtwo.Name = "butMewtwo";
            butMewtwo.Size = new Size(438, 288);
            butMewtwo.TabIndex = 53;
            butMewtwo.UseVisualStyleBackColor = true;
            butMewtwo.Click += butMewtwo_Click;
            // 
            // butVenusaur
            // 
            butVenusaur.Anchor = AnchorStyles.Right;
            butVenusaur.BackgroundImage = (Image)resources.GetObject("butVenusaur.BackgroundImage");
            butVenusaur.BackgroundImageLayout = ImageLayout.Zoom;
            butVenusaur.Location = new Point(425, 542);
            butVenusaur.Margin = new Padding(8, 7, 8, 7);
            butVenusaur.Name = "butVenusaur";
            butVenusaur.Size = new Size(438, 288);
            butVenusaur.TabIndex = 52;
            butVenusaur.UseVisualStyleBackColor = true;
            butVenusaur.Click += butVenusaur_Click;
            // 
            // butBlastoise
            // 
            butBlastoise.Anchor = AnchorStyles.Right;
            butBlastoise.BackgroundImage = (Image)resources.GetObject("butBlastoise.BackgroundImage");
            butBlastoise.BackgroundImageLayout = ImageLayout.Zoom;
            butBlastoise.Location = new Point(425, 264);
            butBlastoise.Margin = new Padding(8, 7, 8, 7);
            butBlastoise.Name = "butBlastoise";
            butBlastoise.Size = new Size(438, 288);
            butBlastoise.TabIndex = 51;
            butBlastoise.UseVisualStyleBackColor = true;
            butBlastoise.Click += butBlastoise_Click;
            // 
            // butCharizard
            // 
            butCharizard.Anchor = AnchorStyles.Right;
            butCharizard.BackgroundImage = Properties.Resources.button_charizard1;
            butCharizard.BackgroundImageLayout = ImageLayout.Zoom;
            butCharizard.Location = new Point(1705, 264);
            butCharizard.Margin = new Padding(8, 7, 8, 7);
            butCharizard.Name = "butCharizard";
            butCharizard.Size = new Size(438, 288);
            butCharizard.TabIndex = 50;
            butCharizard.UseVisualStyleBackColor = true;
            butCharizard.Click += butCharizard_Click;
            // 
            // butChoosePoke
            // 
            butChoosePoke.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            butChoosePoke.Location = new Point(30, 1656);
            butChoosePoke.Margin = new Padding(8, 7, 8, 7);
            butChoosePoke.Name = "butChoosePoke";
            butChoosePoke.Size = new Size(345, 307);
            butChoosePoke.TabIndex = 80;
            butChoosePoke.Text = "Choose Pokemon";
            butChoosePoke.UseVisualStyleBackColor = true;
            butChoosePoke.Click += butChoosePoke_Click;
            // 
            // buttonQuit
            // 
            buttonQuit.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonQuit.Location = new Point(2552, 1831);
            buttonQuit.Margin = new Padding(8, 7, 8, 7);
            buttonQuit.Name = "buttonQuit";
            buttonQuit.Size = new Size(152, 235);
            buttonQuit.TabIndex = 81;
            buttonQuit.Text = "Quit";
            buttonQuit.UseVisualStyleBackColor = true;
            buttonQuit.Click += button1_Click;
            // 
            // Team2
            // 
            AutoScaleDimensions = new SizeF(20F, 48F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2735, 2066);
            Controls.Add(buttonQuit);
            Controls.Add(butChoosePoke);
            Controls.Add(butToxicroak);
            Controls.Add(butSylveon);
            Controls.Add(butGroudon);
            Controls.Add(butVikavolt);
            Controls.Add(butBarbaracle);
            Controls.Add(butToxapex);
            Controls.Add(butTalonflame);
            Controls.Add(butZapdos);
            Controls.Add(butSteelix);
            Controls.Add(butAerodactyl);
            Controls.Add(butGengar);
            Controls.Add(butGardevoir);
            Controls.Add(butKrookodile);
            Controls.Add(butFroslass);
            Controls.Add(butIncineroar);
            Controls.Add(butMetagross);
            Controls.Add(butLucario);
            Controls.Add(butTyranitar);
            Controls.Add(butShedinja);
            Controls.Add(butPikachu);
            Controls.Add(butDragonite);
            Controls.Add(butKyogre);
            Controls.Add(butDragapult);
            Controls.Add(butSceptile);
            Controls.Add(butBlaziken);
            Controls.Add(butArticuno);
            Controls.Add(butMewtwo);
            Controls.Add(butVenusaur);
            Controls.Add(butBlastoise);
            Controls.Add(butCharizard);
            Controls.Add(tm2pokemon6);
            Controls.Add(tm2pokemon5);
            Controls.Add(tm2pokemon4);
            Controls.Add(tm2pokemon3);
            Controls.Add(tm2pokemon2);
            Controls.Add(tm2pokemon1);
            Margin = new Padding(8, 7, 8, 7);
            Name = "Team2";
            Text = "Team2";
            Load += Team2_Load;
            ((System.ComponentModel.ISupportInitialize)tm2pokemon1).EndInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon2).EndInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon3).EndInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon4).EndInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon5).EndInit();
            ((System.ComponentModel.ISupportInitialize)tm2pokemon6).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox tm2pokemon1;
        private PictureBox tm2pokemon2;
        private PictureBox tm2pokemon3;
        private PictureBox tm2pokemon4;
        private PictureBox tm2pokemon5;
        private PictureBox tm2pokemon6;
        private Button butToxicroak;
        private Button butSylveon;
        private Button butGroudon;
        private Button butVikavolt;
        private Button butBarbaracle;
        private Button butToxapex;
        private Button butTalonflame;
        private Button butZapdos;
        private Button butSteelix;
        private Button butAerodactyl;
        private Button butGengar;
        private Button butGardevoir;
        private Button butKrookodile;
        private Button butFroslass;
        private Button butIncineroar;
        private Button butMetagross;
        private Button butLucario;
        private Button butTyranitar;
        private Button butShedinja;
        private Button butPikachu;
        private Button butDragonite;
        private Button butKyogre;
        private Button butDragapult;
        private Button butSceptile;
        private Button butBlaziken;
        private Button butArticuno;
        private Button butMewtwo;
        private Button butVenusaur;
        private Button butBlastoise;
        private Button butCharizard;
        private Button butChoosePoke;
        private Button buttonQuit;
    }
}