﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokemonGame
{
    public partial class Team2 : Form
    {
        private Image tm1pokemon1, tm1pokemon2, tm1pokemon3, tm1pokemon4, tm1pokemon5, tm1pokemon6;
        public Team2(Image tm1BackgroundImage1, Image tm1BackgroundImage2, Image tm1BackgroundImage3, Image tm1BackgroundImage4, Image tm1BackgroundImage5, Image tm1BackgroundImage6)
        {
            InitializeComponent();
            tm1pokemon1 = tm1BackgroundImage1;
            tm1pokemon2 = tm1BackgroundImage2;
            tm1pokemon3 = tm1BackgroundImage3;
            tm1pokemon4 = tm1BackgroundImage4;
            tm1pokemon5 = tm1BackgroundImage5;
            tm1pokemon6 = tm1BackgroundImage6;
        }


        Image defaultPokeball = Properties.Resources.Pokeball;

        private void Team2_Load(object sender, EventArgs e)
        {
            tm2pokemon1.BackgroundImage = defaultPokeball;
            tm2pokemon2.BackgroundImage = defaultPokeball;
            tm2pokemon3.BackgroundImage = defaultPokeball;
            tm2pokemon4.BackgroundImage = defaultPokeball;
            tm2pokemon5.BackgroundImage = defaultPokeball;
            tm2pokemon6.BackgroundImage = defaultPokeball;
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
        }

        //quit button
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void butCharizard_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butCharizard.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butCharizard.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butCharizard.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butCharizard.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butCharizard.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butCharizard.BackgroundImage;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            tm2pokemon2.BackgroundImage = defaultPokeball;
        }

        private void butVenusaur_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butVenusaur.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butVenusaur.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butVenusaur.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butVenusaur.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butVenusaur.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butVenusaur.BackgroundImage;
            }
        }

        private void butBlastoise_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butBlastoise.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butBlastoise.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butBlastoise.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butBlastoise.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butBlastoise.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butBlastoise.BackgroundImage;
            }
        }

        private void butVikavolt_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butVikavolt.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butVikavolt.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butVikavolt.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butVikavolt.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butVikavolt.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butVikavolt.BackgroundImage;
            }
        }

        private void butFroslass_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butFroslass.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butFroslass.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butFroslass.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butFroslass.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butFroslass.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butFroslass.BackgroundImage;
            }
        }

        private void butToxicroak_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butToxicroak.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butToxicroak.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butToxicroak.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butToxicroak.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butToxicroak.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butToxicroak.BackgroundImage;
            }
        }

        private void butBlaziken_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butBlaziken.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butBlaziken.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butBlaziken.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butBlaziken.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butBlaziken.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butBlaziken.BackgroundImage;
            }
        }

        private void butSceptile_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butSceptile.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butSceptile.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butSceptile.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butSceptile.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butSceptile.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butSceptile.BackgroundImage;
            }
        }

        private void butDragapult_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butDragapult.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butDragapult.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butDragapult.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butDragapult.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butDragapult.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butDragapult.BackgroundImage;
            }
        }

        private void butKrookodile_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butKrookodile.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butKrookodile.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butKrookodile.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butKrookodile.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butKrookodile.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butKrookodile.BackgroundImage;
            }
        }

        private void butSylveon_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butSylveon.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butSylveon.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butSylveon.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butSylveon.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butSylveon.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butSylveon.BackgroundImage;
            }
        }

        private void butPikachu_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butPikachu.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butPikachu.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butPikachu.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butPikachu.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butPikachu.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butPikachu.BackgroundImage;
            }
        }

        private void butShedinja_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butShedinja.BackgroundImage;
            }
        }

        private void butTyranitar_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butTyranitar.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butTyranitar.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butTyranitar.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butTyranitar.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butTyranitar.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butTyranitar.BackgroundImage;
            }
        }

        private void butGardevoir_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butGardevoir.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butGardevoir.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butGardevoir.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butGardevoir.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butGardevoir.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butGardevoir.BackgroundImage;
            }
        }

        private void butDragonite_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butDragonite.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butDragonite.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butDragonite.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butDragonite.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butDragonite.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butDragonite.BackgroundImage;
            }
        }

        private void butIncineroar_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butIncineroar.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butIncineroar.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butIncineroar.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butIncineroar.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butIncineroar.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butIncineroar.BackgroundImage;
            }
        }

        private void butMetagross_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butMetagross.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butMetagross.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butMetagross.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butMetagross.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butMetagross.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butMetagross.BackgroundImage;
            }
        }

        private void butLucario_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butLucario.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butLucario.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butLucario.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butLucario.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butLucario.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butLucario.BackgroundImage;
            }
        }

        private void butGengar_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butGengar.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butGengar.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butGengar.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butGengar.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butGengar.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butGengar.BackgroundImage;
            }
        }

        private void butAerodactyl_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butAerodactyl.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butAerodactyl.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butAerodactyl.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butAerodactyl.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butAerodactyl.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butAerodactyl.BackgroundImage;
            }
        }

        private void butSteelix_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butSteelix.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butSteelix.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butSteelix.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butSteelix.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butSteelix.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butSteelix.BackgroundImage;
            }
        }

        private void butBarbaracle_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butBarbaracle.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butBarbaracle.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butBarbaracle.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butBarbaracle.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butBarbaracle.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butBarbaracle.BackgroundImage;
            }
        }

        private void butTalonflame_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butTalonflame.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butTalonflame.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butTalonflame.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butTalonflame.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butTalonflame.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butTalonflame.BackgroundImage;
            }
        }

        private void butToxapex_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butToxapex.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butToxapex.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butToxapex.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butToxapex.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butToxapex.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butToxapex.BackgroundImage;
            }
        }

        private void butKyogre_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butKyogre.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butKyogre.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butKyogre.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butKyogre.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butKyogre.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butKyogre.BackgroundImage;
            }
        }

        private void butArticuno_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butArticuno.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butArticuno.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butArticuno.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butArticuno.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butArticuno.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butArticuno.BackgroundImage;
            }
        }

        private void butZapdos_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butZapdos.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butZapdos.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butZapdos.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butZapdos.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butZapdos.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butZapdos.BackgroundImage;
            }
        }

        private void butMewtwo_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butMewtwo.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butMewtwo.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butMewtwo.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butMewtwo.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butMewtwo.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butMewtwo.BackgroundImage;
            }
        }

        private void butGroudon_Click(object sender, EventArgs e)
        {
            if (tm2pokemon1.BackgroundImage == defaultPokeball)
            {
                tm2pokemon1.BackgroundImage = butGroudon.BackgroundImage;
            }
            else if (tm2pokemon2.BackgroundImage == defaultPokeball)
            {
                tm2pokemon2.BackgroundImage = butGroudon.BackgroundImage;
            }
            else if (tm2pokemon3.BackgroundImage == defaultPokeball)
            {
                tm2pokemon3.BackgroundImage = butGroudon.BackgroundImage;
            }
            else if (tm2pokemon4.BackgroundImage == defaultPokeball)
            {
                tm2pokemon4.BackgroundImage = butGroudon.BackgroundImage;
            }
            else if (tm2pokemon5.BackgroundImage == defaultPokeball)
            {
                tm2pokemon5.BackgroundImage = butShedinja.BackgroundImage;
            }
            else if (tm2pokemon6.BackgroundImage == defaultPokeball)
            {
                tm2pokemon6.BackgroundImage = butGroudon.BackgroundImage;
            }
        }

        private void pokemon1_Click(object sender, EventArgs e)
        {
            tm2pokemon1.BackgroundImage = defaultPokeball;
        }

        private void pokemon3_Click(object sender, EventArgs e)
        {
            tm2pokemon3.BackgroundImage = defaultPokeball;
        }

        private void pokemon4_Click(object sender, EventArgs e)
        {
            tm2pokemon4.BackgroundImage = defaultPokeball;
        }

        private void pokemon5_Click(object sender, EventArgs e)
        {
            tm2pokemon5.BackgroundImage = defaultPokeball;
        }

        private void pokemon6_Click(object sender, EventArgs e)
        {
            tm2pokemon6.BackgroundImage = defaultPokeball;
        }
        public void firstPokemonSelected(Image pokemon)
        {
            Image image = pokemon;
        }
        public static class GlobalData
        {
            public static Image SharedImage { get; set; }

        }
        private void butChoosePoke_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Battle = new Battle(tm1pokemon1, tm1pokemon2, tm1pokemon3, tm1pokemon4, tm1pokemon5, tm1pokemon6, tm2pokemon1.BackgroundImage, tm2pokemon2.BackgroundImage, tm2pokemon3.BackgroundImage, tm2pokemon4.BackgroundImage, tm2pokemon5.BackgroundImage, tm2pokemon6.BackgroundImage);
            Battle.Closed += (s, args) => this.Close();
            Battle.Show();
        }


        //For pokemon sprites use the Gen 7 sprites as buttons to select.

    }
}



