﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonGame
{
    internal class GlobalData
    {
        public static Image SharedImage { get; set; }
    }
}
